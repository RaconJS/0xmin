./r2emulator 2048.bin 1 600
